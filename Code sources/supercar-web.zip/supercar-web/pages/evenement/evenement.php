<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evenement</title>

    <!-- FICHIER CSS DE BOOTSTRAP -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="../../css/style.css">
</head>

<body>

    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-md navbar-dark bg-light">

        <div class="container"> 
    
            <a class="navbar-brand" href="../../index.php">
                <img src="../../img/logo.png" alt="" id="logo">
            </a>
    
            <!-- LE TOGGER A TROIS BARRES -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
    
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto text-center">
    
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">ACCUEIL</a>
                    </li>
    
                    <li class="nav-item">
                        <a class="nav-link" href="../voitures/2-0-voitures.php">VOITURES</a>
                    </li>
    
                    <li class="nav-item">
                        <a class="nav-link" href="../login/seconnecter.php">DEMANDE D'ESSAI</a>
                    </li>
    
                    <li class="nav-item">
                        <a class="nav-link" href="#">EVENEMENTS</a>
                    </li>
    
                    <li class="nav-item">
                        <a class="nav-link" href="../contact/contactez-nous.php">CONTACTEZ-NOUS</a>
                    </li>
    
                </ul>
            </div>
    
            <a href="../login/inscription_main.php" class="logo-container"> <!-- Retirer fixed-right -->
                <img src="../../img/se-connecter.png" alt="Logo">
            </a>
        </div>
    </nav>  
    
    <br><br>

    <section class="evenement">

        <video autoplay loop muted> <!-- POUR QU'ELLE TOURNE EN BOUCLE -->
            <source src="vidéos/video2.mp4" type="video/mp4">
        </video>

        <div class="row justify-content-center">
            <div class="col-md-8">

                <!-- CODE POUR MON BTS BLANC -->
                <?php
                // POUR LANCER UNE NOUVELLE SESSION 
                session_start();

                // POUR RAJOUTER UNE CONSULTATION EN PLUS DES QU'UN AUTRE UTILISATEUR SUPERCAR VISITE 
                if (!isset($_SESSION['views'])) { // si pas encore def
                    $_SESSION['views'] = 1;
                } else {
                    $_SESSION['views']++; // sinon +1 a la valeur init. 
                }
                $total_views = $_SESSION['views'];

                // Connexion à la base de données
                $connexion = new mysqli("localhost", "root", "", "supercar");
                if ($connexion->connect_error) {
                    die("Connection failed: " . $connexion->connect_error);
                }

                // FONCTION DE DATE POUR J actuel 
                $date_actuelle = date("Y-m-d");

                // SELECT NOMBRE EVENEMENT SUP OU EGAL A DATE DU JOUR 
                $actif = "SELECT COUNT(*) AS active_events FROM evenements WHERE date_evenement >= '$date_actuelle'";
                $resultat = $connexion->query($actif);
                $maintenant = mysqli_fetch_assoc($resultat);
                $active_events = $maintenant['active_events'];

                echo '<h1 align="center" id="id1">';
                echo 'EVENEMENTS ORGANISES PAR SUPERCAR !';
                echo '</h1>';
                echo '<br>';
                echo '<div class="row justify-content-between">';
                echo '<div class="col-md-4 text-center" style="background-color: blue; color: white; padding: 10px;">';
                echo 'Nombre d\'événements actifs : ' . $active_events;
                echo '</div>';
                echo '<div class="col-md-4 text-center" style="background-color: blue; color: white; padding: 10px;">';
                echo 'Nombre de consultations : ' . $total_views;
                echo '</div>';
                echo '</div>';
                ?>
            </div>        
        </div>
     
        <br><br><br>

        <?php
        // Récupération des données de la base
        $query = "SELECT * FROM evenements ";
        $result = $connexion->query($query);

        // Construire le container Bootstrap avec les données de la voiture
        $container_nouv = "";

        if ($result->num_rows > 0) {
            while($row = mysqli_fetch_assoc($result)) {
                $container_nouv .= '<div class="row justify-content-center" id="events">';
                $container_nouv .= '<div class="col-md-6">';
                $container_nouv .= '<img src="' . $row["photo"] . '" alt="Image de l\'événement">';
                $container_nouv .= '</div>';
                $container_nouv .= '<div class="col-md-6">';
                $container_nouv .= '<h2><b>'. $row["titre"] .'</b></h2>';
                $container_nouv .= '<p><b id="texte-gras">Date :</b>'. $row["date_evenement"] .'</p>';
                $container_nouv .= '<p><b id="texte-gras">Heure :</b>'. $row["heure"] .'</p>';
                $container_nouv .= '<p><b id="texte-gras">Lieu :</b>'. $row["lieu"] .'</p>';
                $container_nouv .= '<p><b id="texte-gras">Type de voiture :</b>'. $row["type_voiture"] .'</p>';
                $container_nouv .= '<p><b id="texte-gras">Description de l\'événement :</b>'. $row["description"] .'</p>';
                $container_nouv .= '<a href="../contact/contactez-nous.php" class="btn">Participer</a>';
                $container_nouv .= '</div>';
                $container_nouv .= '</div>';
                $container_nouv .= '<br><br><br>';
            }
        } else {
            $container_nouv = "0 résultats";
        }

        // Affichage du contenu de $container_nouv
        echo $container_nouv;

        // Fermer la connexion à la base de données
        $connexion->close();
        ?>

    </section>

    <!-- LE FOOTER DE NOTRE SITE -->
    <footer class="footer">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-11">
                    <label for="" align="left">
                            © 2023 SUPER CAR.MU .Tous droits réservés. <br>
                            | MU.lot54 Battiment4  |
                            | contact@supercar.com |
                            |   +230 3215 8794     |
                            | <a href="" id="link-footer">
                                Politique de confidentialité
                            </a> |
                            |  <a href="" id="link-footer">
                                Conditions d'utilisation
                            </a> |
                            |  <a href="" id="link-footer">
                                Gérer vos cookies
                            </a> |
                            |  <a href="" id="link-footer">
                                Mention légales
                            </a> |
                            |   Suivez-nous sur <img src="../voitures/icones/icons8-facebook-32.png" alt="" height="20px" width="20px" id="footer-image">
                                                <img src="../voitures/icones/icons8-instagram-48.png" alt="" height="20px" width="20px" id="footer-image">
                                                <img src="../voitures/icones/icons8-logo-linkedin-48 (1).png" alt="" height="20px" width="20px" id="footer-image">
                                                <img src="../voitures/icones/icons8-logo-skype-48.png" alt="" height="20px" width="20px" id="footer-image"> | <br>
                    </label>              
                </div>
            </div>
        </div>
    </footer>

    <!-- FICHIER JS DE BOOTSTRAP (dans body : eviter ralentir page > pas indispensable) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
