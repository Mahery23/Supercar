<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inscription</title>
  <!-- Liens vers les fichiers CSS de Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../../css/style.css">
</head>
<body>

    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-md navbar-dark bg-light">

        <div class="container"> 
    
            <a class="navbar-brand" href="#">
                <img src="../../img/logo.png" alt="" id = "logo">
            </a>
    
            <!-- LE TOGGER A TROIS BARRES -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
    
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto text-center">
    
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">ACCUEIL</a>
                    </li>
    
                    <li class="nav-item">
                        <a class="nav-link" href="../voitures/2-0-voitures.php">VOITURES</a>
                    </li>
    
                    <li class="nav-item">
                        <a class="nav-link" href="../login/seconnecter.php">DEMANDE ESSAI</a>
                    </li>
    
                    <li class="nav-item">
                        <a class="nav-link" href="../evenement/evenement.php">EVENEMENTS</a>
                    </li>
    
                    <li class="nav-item">
                        <a class="nav-link" href="#">CONTACTEZ-NOUS</a>
                    </li>
    
                </ul>
            </div>
    
            <a href="../login/inscription_main.php" class="logo-container"> <!-- Retirer fixed-right -->
                <img src="../../img/se-connecter.png" alt="Logo">
            </a>
        </div>
    </nav>

    <!-- SECTION CONTACT --> 
<section class="contact" id="contact">
    <video autoplay loop muted> <!-- POUR QU'ELLE TOURNE EN BOUCLE -->
        <source src="../../mp4/route-couche-soleil.webm" type="video/mp4">
    </video>
    <div class="container-fluid">

        <div class="row">
            <!-- Partie de gauche -->
        <section class="cote-contact col-sm-2 text-center">
            <h3>Détails de contact</h3>
            <br>
            <br>
            <h5>- email : supercar@gmail.com</h5>
            <br>
            <br>
            <br>
            <h5>- tel : <br>(+230) 58 99 25 78 12</h5>
            <br>
            <br>
            <br>
            <h5>- adresse : <br>TG TOWER, Ebene, Maurice.</h5>
            <br>
        </section>

        <div class = "col-sm-1">

        </div>

        <!-- milieu avec le formulaire -->
            
        <div class="col-sm-6 text-center">

            <form class="form-contact" action="contact.php" method="post" style="width: 75%;"  >

                <div class="form-group">

                    <label for="sexe">Sexe</label>

                    <select class="form-control" id="sexe" name="sexe">
                        <option value="homme">Homme</option>
                        <option value="femme">Femme</option>
                    </select>

                </div>

                <div class="form-group">
                    <label for="nom">Nom</label>
                    <input type="text" class="form-control" id="nom" name="nom" required>
                </div>

                <div class="form-group">
                    <label for="prenom">Prénom</label>
                    <input type="text" class="form-control" id="prenom" name="prenom" required>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>

                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
                </div>
                
                <!-- envoyer la reponse -->
                <button type="submit" class="btn btn-primary" name="submit">Envoyer</button>
            </form>
        </div>

        <div class = "col-sm-1">

        </div>

            <!-- Partie de droite -->
        <div class="cote-droite col-sm-2 text-center">
        
            <h5>NOTRE LOCALISATION</h5>
            <!-- Ajoutez le lien autour de l'image -->
            <a href="https://www.google.com/maps/place/NG+Tower/@-20.2475907,57.4886613,17.41z/data=!4m9!1m2!2m1!1smcci!3m5!1s0x217c5b1c17f38899:0x2060b29c1ab59b3e!8m2!3d-20.2476715!4d57.4915392!16s%2Fg%2F11r9blpwh?entry=ttu" target="_blank">
                <img src="../../img/emplacement.png" alt="Emplacement du site" class="img-fluid">
            </a>

            <h5><BR><BR></BR></BR></BDo>VISUALISATION</h5>
            <img src="../../img/lieu.png" alt="UNE PHOTO" class="img-fluid">
        </div>
            
        </div>
    </div>
</section>

    <!-- LE FOOTER DE NOTRE SITE -->

    <footer class="footer">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-11">
                    <label for="" align="left">
                            © 2023 SUPER CAR.MU .Tous droits réservés. <br>
                            | MU.lot54 Battiment4  |
                            | contact@supercar.com |
                            |   +230 3215 8794     |
                            | <a href="" id="link-footer">
                                Politique de confidentialité
                            </a> |
                            |  <a href="" id="link-footer">
                                Conditions d'utilisation
                            </a> |
                            |  <a href="" id="link-footer">
                                Gérer vos cookies
                            </a> |
                            |  <a href="" id="link-footer">
                                Mention légales
                            </a> |
                            |   Suivez-nous sur <img src="icones/icons8-facebook-32.png" alt="" height="20px" width="20px">
                                                <img src="icones/icons8-instagram-48.png" alt="" height="20px" width="20px">
                                                <img src="icones/icons8-logo-linkedin-48 (1).png" alt="" height="20px" width="20px">
                                                <img src="icones/icons8-logo-skype-48.png" alt="" height="20px" width="20px"> | <br>
                    </label>              
                </div>
            </div>
        </div>
    </footer>
        <!-- FICHIER JS DE BOOTSTRAP (dans body : eviter ralentir page > pas indispensable) -->
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>